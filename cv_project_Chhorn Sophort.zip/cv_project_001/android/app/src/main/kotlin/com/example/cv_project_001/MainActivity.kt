package com.example.cv_project_001

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
